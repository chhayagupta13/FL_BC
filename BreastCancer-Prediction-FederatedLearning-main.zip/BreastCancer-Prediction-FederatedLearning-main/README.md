# BreastCancer-Prediction-FederatedLearning
PyTorch-based federated learning for breast cancer prediction, ensuring privacy and collaborative model training.
